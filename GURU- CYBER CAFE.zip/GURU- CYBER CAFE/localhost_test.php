<?php
// Localhost Test Script
echo '<h2>Localhost Server is Running!</h2>';
echo '<p>Server Name: ' . $_SERVER['SERVER_NAME'] . '</p>';
echo '<p>Server Address: ' . $_SERVER['SERVER_ADDR'] . '</p>';
echo '<p>Document Root: ' . $_SERVER['DOCUMENT_ROOT'] . '</p>';
echo '<p>Current File: ' . __FILE__ . '</p>';
?>
