<?php
// PHP Info Script
phpinfo();
?>
